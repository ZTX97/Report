package pojo0318;

/**
 * 
 * @author Simon
 * @version 1.0 2017-11-17
 *
 */

public class Reader {
	private int rid;
	private String rname;
	private String ridcard;
	
	public int getRid() {
		return rid;
	}
	public void setRid(int rid) {
		this.rid = rid;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public String getRidcard() {
		return ridcard;
	}
	public void setRidcard(String ridcard) {
		this.ridcard = ridcard;
	}
}
